﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection.Emit;

using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ti_lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            efficiencyLabel.Visible = false;
        }

        private void encodeButton_Click(object sender, EventArgs e) // кнопка "вывести код"
        {
            string proverb = proverbTextBox.Text.ToLower();
            if (string.IsNullOrWhiteSpace(proverb))
            {
                MessageBox.Show("Введите пословицу или загрузите из файла!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            EncodeProverb(proverb);
        }

        private void loadFromFileButton_Click(object sender, EventArgs e) // кнопка "выбрать файл"
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        string proverb = File.ReadAllText(openFileDialog.FileName).ToLower();
                        proverbTextBox.Text = proverb;
                        EncodeProverb(proverb);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка чтения файла: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void EncodeProverb(string proverb)
        {
            efficiencyLabel.Visible = true;
            Dictionary<char, int> charFrequencies = CalculateFrequencies(proverb); // подсчитываем частоты символов

            double entropy = CalculateEntropy(charFrequencies, proverb.Length); // вычисляем энтропию

            // код Шеннона-Фано
            Dictionary<char, string> shannonFanoCodes = ShannonFanoEncode(charFrequencies);
            // вычисляем среднюю длину и избыточность
            double shannonFanoAverageLength = CalculateAverageLength(shannonFanoCodes, charFrequencies, proverb.Length);
            double shannonFanoRedundancy = CalculateRedundancy(entropy, shannonFanoAverageLength);
            DisplayCodes(shannonFanoCodes, charFrequencies, proverb.Length, shannonFanoListBox, shannonFanoAverageLength, shannonFanoRedundancy, entropy);

            // Код Хаффмана
            Dictionary<char, string> huffmanCodes = HuffmanEncode(charFrequencies);
            // вычисляем среднюю длину и избыточность
            double huffmanAverageLength = CalculateAverageLength(huffmanCodes, charFrequencies, proverb.Length);
            double huffmanRedundancy = CalculateRedundancy(entropy, huffmanAverageLength);
            DisplayCodes(huffmanCodes, charFrequencies, proverb.Length, huffmanListBox, huffmanAverageLength, huffmanRedundancy, entropy);

            // определяем, какой код эффективнее
            if (huffmanAverageLength < shannonFanoAverageLength)
            {
                efficiencyLabel.Text = "Код Хаффмана эффективнее";
            }
            else if (huffmanAverageLength > shannonFanoAverageLength)
            {
                efficiencyLabel.Text = "Код Шеннона-Фано эффективнее";
            }
            else
            {
                efficiencyLabel.Text = "Коды имеют одинаковую эффективность";
            }
        }

        // подсчет частот символов
        static Dictionary<char, int> CalculateFrequencies(string text)
        {
            Dictionary<char, int> frequencies = new Dictionary<char, int>(); // создание словаря
            foreach (char c in text) // перебор символов в тексте
            {
                char lowerChar = char.ToLower(c); // преобразование символа в нижний регистр
                if (frequencies.ContainsKey(lowerChar)) // проверка наличия ключа
                {
                    frequencies[lowerChar]++;
                }
                else
                {
                    frequencies[lowerChar] = 1;
                }
            }
            return frequencies;
        }

        // энтропия
        static double CalculateEntropy(Dictionary<char, int> frequencies, int totalLength)
        {
            double entropy = 0;
            foreach (var pair in frequencies) // перебор пар "символ-частота"
            {
                double probability = (double)pair.Value / totalLength; // вычисление вероятности
                entropy -= probability * Math.Log(probability, 2);
            }
            return entropy;
        }

        // код Шеннона-Фано
        static Dictionary<char, string> ShannonFanoEncode(Dictionary<char, int> frequencies)
        {
            // сортируем символы по частоте убывания.
            List<KeyValuePair<char, int>> sortedFrequencies = frequencies.ToList();
            sortedFrequencies.Sort((x, y) => y.Value.CompareTo(x.Value));

            Dictionary<char, string> codes = new Dictionary<char, string>();
            // рекурсивно разделяем список на две части и присваиваем коды
            foreach (var freq in sortedFrequencies)
            {
                codes[freq.Key] = "";
            }
            //AssignShannonFanoCodes(sortedFrequencies, codes, "");
            AssignShannonFanoCodes(sortedFrequencies, codes, 0, sortedFrequencies.Count - 1);
            return codes;
        }
        private static void AssignShannonFanoCodes(List<KeyValuePair<char, int>> list, Dictionary<char, string> codes, int L, int R)
        {
            if (L < R)
            {
                int n = Delenie_Posledovatelnosty(list, L, R);

                for (int i = L; i <= R; i++)
                {
                    if (i <= n)
                    {
                        codes[list[i].Key] = codes[list[i].Key] + "1";
                    }
                    else
                    {
                        codes[list[i].Key] = codes[list[i].Key] + "0";
                    }
                }

                AssignShannonFanoCodes(list, codes, L, n);
                AssignShannonFanoCodes(list, codes, n + 1, R);
            }
        }

        private static int Delenie_Posledovatelnosty(List<KeyValuePair<char, int>> list, int L, int R)
        {
            double schet1 = list[L].Value;
            double schet2 = 0;

            for (int i = L + 1; i <= R; i++)
            {
                schet2 += list[i].Value;
            }

            int m = L;
            double minDifference = Math.Abs(schet1 - schet2);

            for (int i = L + 1; i <= R; i++)
            {
                schet1 += list[i].Value;
                schet2 -= list[i].Value;

                double currentDifference = Math.Abs(schet1 - schet2);

                if (currentDifference < minDifference)
                {
                    minDifference = currentDifference;
                    m = i;
                }
            }

            return m;
        }

        // код Хаффмана
        static Dictionary<char, string> HuffmanEncode(Dictionary<char, int> frequencies)
        {
            // создаем список для хранения узлов дерева Хаффмана
            List<HuffmanNode> nodeList = new List<HuffmanNode>();
            foreach (var pair in frequencies)
            {
                nodeList.Add(new HuffmanNode(pair.Key, pair.Value));
            }

            // построение дерева Хаффмана
            while (nodeList.Count > 1)
            {
                // сортируем узлы по частоте (вручную, т.к. нет PriorityQueue)
                nodeList.Sort((x, y) => x.Frequency.CompareTo(y.Frequency));

                HuffmanNode left = nodeList[0];
                HuffmanNode right = nodeList[1];

                // удаляем из списка извлечённые
                nodeList.RemoveAt(0);
                nodeList.RemoveAt(0);
                // создаем новый узел и добавляем его в список
                HuffmanNode combined = new HuffmanNode(null, left.Frequency + right.Frequency) { Left = left, Right = right };
                nodeList.Add(combined);
            }
            HuffmanNode root = nodeList[0];

            // получаем коды из построенного дерева
            Dictionary<char, string> codes = new Dictionary<char, string>();
            GetHuffmanCodes(root, "", codes);

            return codes;
        }

        static void GetHuffmanCodes(HuffmanNode node, string code, Dictionary<char, string> codes)
        {
            if (node.Character != null) // проверка, является ли узел листом
            {
                codes[node.Character.Value] = code;
                return;
            }

            if (node.Left != null) // проверка наличия левого потомка
            {
                GetHuffmanCodes(node.Left, code + "0", codes);
            }

            if (node.Right != null) // проверка наличия правого потомка
            {
                GetHuffmanCodes(node.Right, code + "1", codes);
            }
        }

        // класс для представления узла дерева Хаффмана
        class HuffmanNode
        {
            public char? Character { get; set; }
            public int Frequency { get; set; }
            public HuffmanNode Left { get; set; }
            public HuffmanNode Right { get; set; }

            public HuffmanNode(char? character, int frequency)
            {
                Character = character;
                Frequency = frequency;
            }
        }

        // вычисление средней длины кода
        static double CalculateAverageLength(Dictionary<char, string> codes, Dictionary<char, int> frequencies, int totalLength)
        {
            double averageLength = 0;
            foreach (var pair in codes)
            {
                double probability = (double)frequencies[pair.Key] / totalLength;
                averageLength += probability * pair.Value.Length;
            }
            return averageLength;
        }

        // вычисление избыточности
        static double CalculateRedundancy(double entropy, double averageLength)
        {
            return averageLength - entropy;
        }

        // вывод в ListBox
        private void DisplayCodes(Dictionary<char, string> codes, Dictionary<char, int> frequencies, int totalLength, ListBox listBox, double averageLength, double redundancy, double entropy)
        {
            listBox.Items.Clear();

            // Создаем список для сортировки
            var sortedCodes = codes.Select(pair => new
            {
                Character = pair.Key,
                Code = pair.Value,
                Probability = (double)frequencies[pair.Key] / totalLength
            }).OrderByDescending(x => x.Probability).ToList();

            // Выводим отсортированные данные
            foreach (var item in sortedCodes)
            {
                listBox.Items.Add($"'{item.Character}'    {item.Probability:F5}    {item.Code}");
            }
            listBox.Items.Add($"H(A): {entropy:F5} Lср: {averageLength:F5}, D: {redundancy:F5}");
        }
    }
}



