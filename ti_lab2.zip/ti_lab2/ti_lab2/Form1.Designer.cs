﻿namespace ti_lab2
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.proverbTextBox = new System.Windows.Forms.TextBox();
            this.encodeButton = new System.Windows.Forms.Button();
            this.shannonFanoListBox = new System.Windows.Forms.ListBox();
            this.huffmanListBox = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.loadFromFileButton = new System.Windows.Forms.Button();
            this.efficiencyLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(175, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Введите пословицу";
            // 
            // proverbTextBox
            // 
            this.proverbTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.proverbTextBox.Location = new System.Drawing.Point(203, 13);
            this.proverbTextBox.Name = "proverbTextBox";
            this.proverbTextBox.Size = new System.Drawing.Size(529, 27);
            this.proverbTextBox.TabIndex = 1;
            // 
            // encodeButton
            // 
            this.encodeButton.BackColor = System.Drawing.Color.PaleTurquoise;
            this.encodeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.encodeButton.Location = new System.Drawing.Point(567, 54);
            this.encodeButton.Name = "encodeButton";
            this.encodeButton.Size = new System.Drawing.Size(165, 50);
            this.encodeButton.TabIndex = 2;
            this.encodeButton.Text = "Вывести код";
            this.encodeButton.UseVisualStyleBackColor = false;
            this.encodeButton.Click += new System.EventHandler(this.encodeButton_Click);
            // 
            // shannonFanoListBox
            // 
            this.shannonFanoListBox.FormattingEnabled = true;
            this.shannonFanoListBox.ItemHeight = 16;
            this.shannonFanoListBox.Location = new System.Drawing.Point(12, 146);
            this.shannonFanoListBox.Name = "shannonFanoListBox";
            this.shannonFanoListBox.Size = new System.Drawing.Size(317, 324);
            this.shannonFanoListBox.TabIndex = 3;
            // 
            // huffmanListBox
            // 
            this.huffmanListBox.FormattingEnabled = true;
            this.huffmanListBox.ItemHeight = 16;
            this.huffmanListBox.Location = new System.Drawing.Point(393, 146);
            this.huffmanListBox.Name = "huffmanListBox";
            this.huffmanListBox.Size = new System.Drawing.Size(339, 324);
            this.huffmanListBox.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(12, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(163, 22);
            this.label2.TabIndex = 5;
            this.label2.Text = "Код Шенона Фано";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(389, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(141, 22);
            this.label3.TabIndex = 6;
            this.label3.Text = "Код Хаффмана";
            // 
            // loadFromFileButton
            // 
            this.loadFromFileButton.BackColor = System.Drawing.Color.Lavender;
            this.loadFromFileButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.loadFromFileButton.Location = new System.Drawing.Point(17, 54);
            this.loadFromFileButton.Name = "loadFromFileButton";
            this.loadFromFileButton.Size = new System.Drawing.Size(176, 42);
            this.loadFromFileButton.TabIndex = 7;
            this.loadFromFileButton.Text = "Загрузить файл";
            this.loadFromFileButton.UseVisualStyleBackColor = false;
            this.loadFromFileButton.Click += new System.EventHandler(this.loadFromFileButton_Click);
            // 
            // efficiencyLabel
            // 
            this.efficiencyLabel.AutoSize = true;
            this.efficiencyLabel.BackColor = System.Drawing.Color.MistyRose;
            this.efficiencyLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.efficiencyLabel.Location = new System.Drawing.Point(308, 496);
            this.efficiencyLabel.Name = "efficiencyLabel";
            this.efficiencyLabel.Size = new System.Drawing.Size(65, 20);
            this.efficiencyLabel.TabIndex = 8;
            this.efficiencyLabel.Text = "Вывод";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 540);
            this.Controls.Add(this.efficiencyLabel);
            this.Controls.Add(this.loadFromFileButton);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.huffmanListBox);
            this.Controls.Add(this.shannonFanoListBox);
            this.Controls.Add(this.encodeButton);
            this.Controls.Add(this.proverbTextBox);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Lab #2 Методы эффективного кодирования";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox proverbTextBox;
        private System.Windows.Forms.Button encodeButton;
        private System.Windows.Forms.ListBox shannonFanoListBox;
        private System.Windows.Forms.ListBox huffmanListBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button loadFromFileButton;
        private System.Windows.Forms.Label efficiencyLabel;
    }
}

