﻿namespace ti_lab3_2
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.encodeButton = new System.Windows.Forms.Button();
            this.findErrorButton = new System.Windows.Forms.Button();
            this.encodedLabel = new System.Windows.Forms.Label();
            this.correctedLabel = new System.Windows.Forms.Label();
            this.errorPositionLabel = new System.Windows.Forms.Label();
            this.inputTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(33, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Введите данные";
            // 
            // encodeButton
            // 
            this.encodeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.encodeButton.Location = new System.Drawing.Point(480, 12);
            this.encodeButton.Name = "encodeButton";
            this.encodeButton.Size = new System.Drawing.Size(153, 58);
            this.encodeButton.TabIndex = 1;
            this.encodeButton.Text = "Найти код Хемминга";
            this.encodeButton.UseVisualStyleBackColor = true;
            this.encodeButton.Click += new System.EventHandler(this.encodeButton_Click);
            // 
            // findErrorButton
            // 
            this.findErrorButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.findErrorButton.Location = new System.Drawing.Point(639, 12);
            this.findErrorButton.Name = "findErrorButton";
            this.findErrorButton.Size = new System.Drawing.Size(118, 58);
            this.findErrorButton.TabIndex = 2;
            this.findErrorButton.Text = "Найти ошибку";
            this.findErrorButton.UseVisualStyleBackColor = true;
            this.findErrorButton.Click += new System.EventHandler(this.findErrorButton_Click);
            // 
            // encodedLabel
            // 
            this.encodedLabel.AutoSize = true;
            this.encodedLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.encodedLabel.Location = new System.Drawing.Point(33, 75);
            this.encodedLabel.Name = "encodedLabel";
            this.encodedLabel.Size = new System.Drawing.Size(131, 20);
            this.encodedLabel.TabIndex = 3;
            this.encodedLabel.Text = "Код Хемминга";
            // 
            // correctedLabel
            // 
            this.correctedLabel.AutoSize = true;
            this.correctedLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.correctedLabel.Location = new System.Drawing.Point(33, 129);
            this.correctedLabel.Name = "correctedLabel";
            this.correctedLabel.Size = new System.Drawing.Size(164, 20);
            this.correctedLabel.TabIndex = 4;
            this.correctedLabel.Text = "Ошибка в позиции";
            // 
            // errorPositionLabel
            // 
            this.errorPositionLabel.AutoSize = true;
            this.errorPositionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.errorPositionLabel.Location = new System.Drawing.Point(33, 180);
            this.errorPositionLabel.Name = "errorPositionLabel";
            this.errorPositionLabel.Size = new System.Drawing.Size(167, 20);
            this.errorPositionLabel.TabIndex = 5;
            this.errorPositionLabel.Text = "Исправленный код";
            // 
            // inputTextBox
            // 
            this.inputTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.inputTextBox.Location = new System.Drawing.Point(201, 17);
            this.inputTextBox.Name = "inputTextBox";
            this.inputTextBox.Size = new System.Drawing.Size(258, 27);
            this.inputTextBox.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.inputTextBox);
            this.Controls.Add(this.errorPositionLabel);
            this.Controls.Add(this.correctedLabel);
            this.Controls.Add(this.encodedLabel);
            this.Controls.Add(this.findErrorButton);
            this.Controls.Add(this.encodeButton);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Lab №3 ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button encodeButton;
        private System.Windows.Forms.Button findErrorButton;
        private System.Windows.Forms.Label encodedLabel;
        private System.Windows.Forms.Label correctedLabel;
        private System.Windows.Forms.Label errorPositionLabel;
        private System.Windows.Forms.TextBox inputTextBox;
    }
}

