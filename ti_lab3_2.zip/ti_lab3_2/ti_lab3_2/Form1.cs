﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ti_lab3_2
{
    public partial class Form1 : Form
    {
        private int ni; // Длина исходного кода
        private int nk; // Длина контрольных битов
        private int n; // Общая длина кодированного кода

        private string encodedCode = ""; // Закодированный код
        private string originalInputCode = ""; // Исходный код пользователя
        private string correctedCode = ""; // Исправленный код
        private int errorPosition = -1; // Позиция ошибки
        private string decodedCode = ""; // Декодированный код
        public Form1()
        {
            InitializeComponent();
            ni = 8; // Длина исходного кода
            nk = 4; // Длина контрольных битов
            n = ni + nk; // Общая длина кодированного кода
        }
        // Метод для кодирования данных кодом Хэмминга
        private void encodeButton_Click(object sender, EventArgs e)
        {
            // Получаем данные из текстового поля
            string inputBinary = inputTextBox.Text;

            // Проверяем корректность ввода
            if (string.IsNullOrEmpty(inputBinary) || !inputBinary.All(c => c == '0' || c == '1'))
            {
                MessageBox.Show("Введите корректный двоичный код.");
                return;
            }

            // Кодируем данные методом Хэмминга и выводим результат в label
            string encodedBinary = HammingEncode(inputBinary);
            encodedLabel.Text = $"Закодированные данные: {encodedBinary}";

        }
        private void findErrorButton_Click(object sender, EventArgs e)
        {
            // Получаем данные из текстового поля
            string inputCode = inputTextBox.Text;

            // Проверяем корректность ввода
            if (string.IsNullOrEmpty(inputCode) || !inputCode.All(c => c == '0' || c == '1'))
            {
                MessageBox.Show("Введите корректный двоичный код для исправления.");
                return;
            }

            // Исправляем данные методом контрольных сумм и выводим результат
            (string correctedCode, List<int> errorPositions) = ChecksumCorrect(inputCode);
            correctedLabel.Text = $"Исправленные данные: {correctedCode}";

            // Вывод позиций ошибок (если есть)
            if (errorPositions.Count > 0)
            {
                errorPositionLabel.Text = "Позиции ошибок: " + string.Join(", ", errorPositions);
            }
            else
            {
                errorPositionLabel.Text = "Ошибок не найдено.";
            }
        }

        // Метод кодирования Хэмминга
        private string HammingEncode(string input)
        {
            int ni = input.Length;
            // Расчет k - количество контрольных битов (2^k >= ni + k + 1)
            int k = 0;
            while (Math.Pow(2, k) < ni + k + 1)
            {
                k++;
            }

            int n = ni + k;
            char[] encoded = new char[n];

            // Заполнение информационными битами
            int dataIndex = 0;
            for (int i = 1; i <= n; i++)
            {
                if (!IsPowerOfTwo(i))
                {
                    encoded[i - 1] = input[dataIndex];
                    dataIndex++;
                }
            }

            // Расчет и вставка контрольных битов
            for (int i = 0; i < k; i++)
            {
                int parityBitPosition = (int)Math.Pow(2, i) - 1;
                int parity = 0;

                for (int j = 0; j < n; j++)
                {
                    if (((j + 1) & (1 << i)) != 0)
                    {
                        if (encoded[j] == '1')
                        {
                            parity++;
                        }
                    }
                }

                encoded[parityBitPosition] = (parity % 2 == 0) ? '0' : '1';
            }

            return new string(encoded);
        }

        // Метод исправления ошибок контрольными суммами
        private (string, List<int>) ChecksumCorrect(string input)
        {
            int n = input.Length;
            int k = 0;
            // Вычисляем количество контрольных бит, для построения матрицы
            while (Math.Pow(2, k) < n + k + 1)
            {
                k++;
            }


            int parityBits = k; // Количество контрольных битов
            int dataBits = n - parityBits; // Количество информационных битов
            List<int> errorPositions = new List<int>();


            // Вычисляем позиции информационных битов и контрольных
            List<int> parityPositions = new List<int>();
            List<int> dataPositions = new List<int>();
            for (int i = 1; i <= n; i++)
            {
                if (IsPowerOfTwo(i))
                {
                    parityPositions.Add(i - 1);
                }
                else
                {
                    dataPositions.Add(i - 1);
                }
            }

            // Конвертируем входную строку в массив символов
            char[] code = input.ToCharArray();


            // Вычисляем синдром
            int syndrome = 0;
            for (int i = 0; i < parityBits; i++)
            {
                int parity = 0;
                for (int j = 0; j < n; j++)
                {
                    if (((j + 1) & (1 << i)) != 0)
                    {
                        if (code[j] == '1')
                            parity++;
                    }
                }
                // Добавляем к синдрому, если четность не соблюдена
                if (parity % 2 != 0)
                    syndrome += (int)Math.Pow(2, i);
            }

            // Если синдром равен 0, значит ошибок нет
            if (syndrome == 0)
            {
                return (new string(code), errorPositions); // Возвращает исходный код и пустой список ошибок
            }

            // Если синдром не равен 0, то исправляем ошибку
            if (syndrome <= n)
            {
                if (code[syndrome - 1] == '1')
                    code[syndrome - 1] = '0';
                else
                    code[syndrome - 1] = '1';

                errorPositions.Add(syndrome);
            }

            return (new string(code), errorPositions);
        }


        // Метод для проверки, является ли число степенью двойки
        private bool IsPowerOfTwo(int n)
        {
            return (n > 0) && ((n & (n - 1)) == 0);
        }
    }
}
